from fourparts.music_structures.Key import Key
from fourparts.music_structures.Scales import Scales
from fourparts.processes.NoteFrequencies import NoteFrequencies
from fourparts.processes.preprocess import midi_to_df

from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
import pandas as pd


def _parse_data(data):
    """
    Parameters
    ----------
    data : pandas.DataFrame
        Columns:
            Name: Name, dtype: str
                Name of the piece that has been analysed.
            Name: pitchcenter, dtype: str
                Pitchcenter of the piece, as in Notes.NOTES.
            Name: scale, dtype: str
                Either 'major' or 'minor'.
            Name: C, dtype: float
            Name: C#/Db, dtype: float
            Name: D, dtype: float
            Name: D#/Eb, dtype: float
            Name: E, dtype: float
            Name: F, dtype: float
            Name: F#/Gb, dtype: float
            Name: G, dtype: float
            Name: G#/Ab, dtype: float
            Name: A, dtype: float
            Name: A#/Bb, dtype: float
            Name: B, dtype: float
                percentages of the occurences of the note.

    Returns
    -------
    tuple of pd.DataFrame
        At index 0 is all the percentages of note frequencies.
        At index 1 is the keys.
    """

    # TODO: find method to create keys in place
    df_x = data.iloc[:, 3:]
    
    scale_list = list(data['scale'])
    for i in range(len(scale_list)):
        scale_list[i] = Scales.create_scale(scale_list[i])

    df_y = pd.Series(data=[Key.create_key(row['pitchcenter'], scale_list[i]).__str__()
                            for i, row in data.iterrows()],
                     name='keys')

    return df_x, df_y


class KeyClassifier:
    """A class to detect the key of a piece of music.
    Need not be four part writing.

    A neural network is trained using a dataset of
    keys and its associated NoteFrequency percentages.

    sklearn MLPClassifier API:
    https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPClassifier.html

    Attributes
    ----------
    nn : sklearn.neural_network.MLPClassifier
    """

    def __init__(self, max_iter=200, hidden_layer_sizes=(100,)):
        """Constructor method to initialise the MLPClassifier

        Parameters
        ----------
        max_iter : int
            Maximum number of iterations of training to be performed.
            Default is 200.
        hidden_layer_size : tuple of int
            length of tuple = n_layers - 2. With default of (100,).
            The default is the same as sklearns'.
            The ith element represents the number of neurons in the ith hidden layer.
        """

        self.nn = MLPClassifier(activation='logistic',
                                solver='sgd',
                                max_iter=max_iter,
                                hidden_layer_sizes=hidden_layer_sizes,
                                random_state=1)

    def _fit(self, x_train, y_train):
        """Training of neural network.

        Parameters
        ----------
        x_train : numpy array of Keys
        y_train: numpy array of note frequency percentages
        """

        self.nn.fit(x_train, y_train)

    def train(self, data):
        """Actual training of the neural network.

        Parameters
        ----------
        data : pandas.DataFrame
            See _parse_data above.

        Returns
        -------
        self
        """

        df_x, df_y = _parse_data(data)
        self._fit(df_x, df_y)

        return self

    def test_train(self, data, test_size=0.2):
        """Testing of the neural network.

        Parameters
        ----------
        data : pandas.DataFrame
            See _parse_data above.
        test_size : float
            Between 0.0 and 1.0. Determines the ratio of test_samples to use.
            Default is 0.2.

        Returns
        -------
        str
            Results of the training set.
        """

        df_x, df_y = _parse_data(data)
        x_train, x_test, y_train, y_test = train_test_split(df_x,
                                                            df_y,
                                                            test_size=test_size)
        self._fit(x_train, y_train)

        count = 0
        predict = self.nn.predict(x_test)
        total = len(predict)

        for i in range(total):
            if predict[i] == y_test.values[i]:
                count += 1
        
        accuracy = round(count / total * 100, 2)

        return '''
               Correct predictions: {0}
               Total predictions: {1}
               Percentage accuracy: {2}
               '''.format(count, total, accuracy)

    def predict(self, data):
        """Predicts the actual key of data.

        Parameters
        ----------
        data : dict of list of float
            Each element in the list should be a percentage.
            An example:
            {
                'C': [50.0],
                'C#/Db': [0],
                'D': [0],
                'D#/Eb': [50.0],
                'E': [0],
                'F': [0],
                'F#/Gb': [0],
                'G': [0],
                'G#/Ab': [0],
                'A': [0],
                'A#/Bb': [0],
                'B': [0]
            }

        Returns
        -------
        list of Key
        """

        print(self.nn.predict(pd.DataFrame(data)))
        return self.nn.predict(pd.DataFrame(data))

    def predict_midi(self, midi_file):
        """Predicts the key of the given midi file.

        Parameters
        ----------
        midi_file : str
            Directory to the midi file.

        Returns
        -------
        list of Key
        """

        df = midi_to_df(midi_file)
        freq = NoteFrequencies.create_note_frequencies()
        freq.count(df)
        freq_percentage = freq.convert_to_percentage()

        data = {}
        # convert to a dict of list of float
        for key in freq_percentage.keys():
            data[key] = [freq_percentage[key]]

        return self.predict(data)


if __name__ == '__main__':
    data = pd.read_csv('/Users/ruixuan/Desktop/fourparts-ml/ml/key_classifier/train.csv')
    p = KeyClassifier(hidden_layer_sizes=(100,), max_iter=100)
    p.train(data)
    p.predict_midi('samples/chorale_F.mid')
    print(p)
